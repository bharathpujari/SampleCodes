package com.sample.sample.ui.weather

import org.json.JSONObject

interface WeatherApi {n

    // POST /GET / DELETE
    // API Endpoints confirgurratio
    fun getCityWeaather(json : JSONObject)
}
package com.sample.sample.ui.weather.repository

interface WeatherRepository {
    suspend fun fetchCityWeather(cityName : String)

}
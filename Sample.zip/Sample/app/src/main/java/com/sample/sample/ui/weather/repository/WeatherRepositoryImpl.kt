package com.sample.sample.ui.weather.repository

import com.sample.sample.ui.weather.WeatherApi

class WeatherRepositoryImpl @Inject constructor(weatherApi : WeatherApi, ioDispacher : CourutineContext) : WeatherRepository {

    override suspend fun fetchCityWeather(cityName: String) {
            // FLow / Retoriit
    }
}
package com.sample.sample.ui.weather.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sample.sample.ui.weather.repository.WeatherRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class WeatherListViewModel @Inject constructor(val repository : WeatherRepository): ViewModel() {
   private val mweatherList : MutableLiveData<Weather>  = MutableLiveData()

    val weatherList : LiveData<Weather>  =mweatherList




    fun loadDataForCuty(city :String) {
        viewModelScope.launch {

            val result  = withContext(Dispatchers.IO) {
                // do some work
            }
        }
           val response =  repository.fetchCityWeather(city)
            if (response is Result.Success)
            {
                mweatherList.postValue(repsone.list)
            }else
            {
            }
    }


    fun loadDataForCuty(city1 : STring, city2 :String, city3 :String) {
        viewModelScope.launch {
            val respinse1 = async { repository.fetchCityWeather(sity1) }
            val respinse2 = async { repository.fetchCityWeather(sity2) }
            val respinse3 = async { repository.fetchCityWeather(sit3) }

            pocessData(response1.await.body, respinse2.await().body)

        }

    }


    fun  processData() {

    }
}
package com.sample.sample.ui.weather.di

@Module
interface WeatherModule {
    // DI code for viewmodels ans fragment to inject views with viwmodels
    // rep
}